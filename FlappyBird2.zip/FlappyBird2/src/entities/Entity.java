package entities;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Entity {
    private double x;
    private double y;
    private int startY;
    private int width;
    private int height;
    private Rectangle hitbox;
    private BufferedImage img;
}
