package inputs;

import core.Panel;
import core.GameState;
import ui.MenuButton;
import ui.ModeButton;
import ui.ToggleMenuButton;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class MouseInputs implements MouseListener, MouseMotionListener {

    private Panel gamePanel;

    public MouseInputs(Panel gamePanel) {
        this.gamePanel = gamePanel;
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        switch (gamePanel.getGame().getGameState()){
            case START:
                if(isIn(e,gamePanel.getGame().getToggleMenuBtn()[1])){
                    gamePanel.getGame().getToggleMenuBtn()[1].setMousePressed(true);
                    gamePanel.getGame().setGameState(GameState.MENU);
                }else{
                    gamePanel.getGame().setGameState(GameState.PLAYING); //game starts
                }
                break;
            case PLAYING:
                gamePanel.getGame().getPlayer().setJumping(true); //player jumps
                break;
            case GAME_OVER:
                if(isIn(e,gamePanel.getGame().getToggleMenuBtn()[1])){
                    gamePanel.getGame().getToggleMenuBtn()[1].setMousePressed(true);
                    gamePanel.getGame().setGameState(GameState.MENU);
                }else {
                    gamePanel.getGame().setGameState(GameState.START); //game back to start
                }
                break;
            case MENU:
                if(isIn(e,gamePanel.getGame().getToggleMenuBtn()[1])){
                    gamePanel.getGame().getToggleMenuBtn()[1].setMousePressed(true);
                    gamePanel.getGame().setGameState(GameState.START);
                }
                if(isInMenu(e,gamePanel.getGame().getMenuBtnShop()[1])){
                    gamePanel.getGame().getMenuBtnShop()[1].setY(-100);
                    gamePanel.getGame().getMenuBtnShop()[1].setMousePressed(true);
                }else if(isInMenu(e,gamePanel.getGame().getMenuBtnExit()[1])){
                    gamePanel.getGame().getMenuBtnShop()[1].setY(-100);
                    System.exit(0);
                }else if(isInModeMenu(e,gamePanel.getGame().getModeBtnDay()[1])){
                    gamePanel.getGame().getModeBtnDay()[1].setY(-100);
                    gamePanel.getGame().getModeBtnDay()[1].setMousePressed(true);
                    gamePanel.getGame().getBg().setY(0);
                    gamePanel.getGame().getFl().setY(0);

                }else if(isInModeMenu(e,gamePanel.getGame().getModeBtnNight()[1])){
                    gamePanel.getGame().getModeBtnNight()[1].setY(-100);
                    gamePanel.getGame().getModeBtnNight()[1].setMousePressed(true);
                    gamePanel.getGame().getBg().setY(-800);
                    gamePanel.getGame().getFl().setY(-800);

                }
        }

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(gamePanel.getGame().getToggleMenuBtn()[1].isMousePressed()){
            gamePanel.getGame().getToggleMenuBtn()[1].setMousePressed(false);
            gamePanel.getGame().getMenu_bg().setShop(false);
            for(int i = 0; i < 2; i++){
                gamePanel.getGame().getModeBtnDay()[i].setShop(false);
                gamePanel.getGame().getModeBtnNight()[i].setShop(false);
                gamePanel.getGame().getMenuBtnShop()[i].setShop(false);
                gamePanel.getGame().getMenuBtnExit()[i].setShop(false);
            }
        }
        switch (gamePanel.getGame().getGameState()){
            case MENU:
                if(gamePanel.getGame().getMenuBtnShop()[1].isMousePressed()){
                    gamePanel.getGame().getMenuBtnShop()[1].setY(gamePanel.getGame().getMenuBtnShop()[1].getLockY());
                    gamePanel.getGame().getMenuBtnShop()[1].setMousePressed(false);
                    gamePanel.getGame().getMenu_bg().setShop(true);
                    for(int i = 0; i < 2; i++){
                        gamePanel.getGame().getModeBtnDay()[i].setShop(true);
                        gamePanel.getGame().getModeBtnNight()[i].setShop(true);
                        gamePanel.getGame().getMenuBtnShop()[i].setShop(true);
                        gamePanel.getGame().getMenuBtnExit()[i].setShop(true);
                    }
                }else if(gamePanel.getGame().getModeBtnDay()[1].isMousePressed()){
                    gamePanel.getGame().getModeBtnDay()[1].setY(gamePanel.getGame().getModeBtnDay()[1].getLockY());
                    gamePanel.getGame().getModeBtnDay()[1].setMousePressed(false);
                }else if(gamePanel.getGame().getModeBtnNight()[1].isMousePressed()){
                    gamePanel.getGame().getModeBtnNight()[1].setY(gamePanel.getGame().getModeBtnNight()[1].getLockY());
                    gamePanel.getGame().getModeBtnNight()[1].setMousePressed(false);
                }
                break;
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {

    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }

    public boolean isIn(MouseEvent e, ToggleMenuButton btn) {
        return btn.getHitbox().contains(e.getX(), e.getY());
    }

    public boolean isInMenu(MouseEvent e, MenuButton btn) {
        return btn.getHitbox().contains(e.getX(), e.getY());
    }

    public boolean isInModeMenu(MouseEvent e, ModeButton btn) {
        return btn.getHitbox().contains(e.getX(), e.getY());
    }
}
