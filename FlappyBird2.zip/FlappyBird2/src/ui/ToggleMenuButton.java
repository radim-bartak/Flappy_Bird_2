package ui;

import core.GameState;
import core.ImageImport;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Objects;

public class ToggleMenuButton implements ImageImport {

    private int x;
    private int y;
    private int index;
    private GameState gameState;
    private BufferedImage[] buttonImgs;
    private BufferedImage img;
    private boolean mousePressed;
    private Rectangle hitbox;

    public ToggleMenuButton(int x, int y, int index, GameState gameState) {
        this.x = x;
        this.y = y;
        this.index = index;
        this.gameState = gameState;

        importImg();
        hitbox = new Rectangle(x,y,56,57);
    }


    @Override
    public void importImg() {
        buttonImgs = new BufferedImage[2];

        try {
            img = ImageIO.read(Objects.requireNonNull(this.getClass().getResource("/toggle_menu_button.png")));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        for(int i=0;i<buttonImgs.length;i++){
            buttonImgs[i] = img.getSubimage(i * 56, 0,56,57);
        }

    }

    @Override
    public void render(Graphics g) {
        g.drawImage(buttonImgs[index], x,y,56,57,null);

    }

    public void update(){
        if(gameState == GameState.START || gameState == GameState.GAME_OVER || gameState == GameState.MENU){
            if(index == 1){
                if(mousePressed){
                    y = -100;
                }
            }
        }else{
            y = -100;
        }

        hitbox.x = x;
        hitbox.y = y;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public GameState getGameState() {
        return gameState;
    }

    public void setGameState(GameState gameState) {
        this.gameState = gameState;
    }

    public boolean isMousePressed() {
        return mousePressed;
    }

    public void setMousePressed(boolean mousePressed) {
        this.mousePressed = mousePressed;
    }

    public Rectangle getHitbox() {
        return hitbox;
    }

    public void setHitbox(Rectangle hitbox) {
        this.hitbox = hitbox;
    }
}
