package core;

public enum GameState {
    START,
    PLAYING,
    GAME_OVER,
    MENU;

    public static GameState state = MENU;
}